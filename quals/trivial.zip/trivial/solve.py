checkcode = 'AK4782'
change = 'standardisation'[::2]
num = 18529313 / 2
flag = 'CrossCTF{%s_%d_%s}' % (change, num, checkcode)
print(flag)